#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "build_model.h"

#ifdef unix
#include <unistd.h>
#endif

#include <mikenet/simulator.h>

//INSERT_FLAG_INCLUDES

#define NUM_TEST_SETS 0
#define NUM_PHASES 1
#define NUM_PHASE_ITEMS 1
#define TIME 3
#define SEED 0
#define WEIGHT_RANGE 0.1
char run_name[]="XOR_3242015_5_iters_1";

int p,q;
Phase *phases[NUM_PHASES];
PhaseItem *phase_items[NUM_PHASE_ITEMS];
TestSet *test_sets[NUM_TEST_SETS];

void construct(Net *run_net) {
	/* create runNet which is a net struct containing all groups and connections.*/
	run_net=create_net(TIME);
	
	Group *g1, *g2, *g3, *bias;
	Connections *c1, *c2, *c3, *c4;
	
	/* create all groups. 
	   format is: name, num of units,  ticks */ 
	g1=init_group("Input",2,TIME);
	g1->activationType=LOGISTIC_ACTIVATION;
	g1->errorComputation=SUM_SQUARED_ERROR;
	g2=init_group("Hidden",10,TIME);
	g2->activationType=LOGISTIC_ACTIVATION;
	g2->errorComputation=SUM_SQUARED_ERROR;
	g3=init_group("Output",1,TIME);
	g3->activationType=LOGISTIC_ACTIVATION;
	g3->errorComputation=SUM_SQUARED_ERROR;
	bias=init_bias(1.0,TIME);
	
	/* now add our groups to the run network object */ 
	bind_group_to_net(run_net,g1);
	bind_group_to_net(run_net,g2);
	bind_group_to_net(run_net,g3);
	bind_group_to_net(run_net,bias);
	
	/* now instantiate connection objects */ 
	c1=connect_groups(g1,g2);
	c2=connect_groups(g2,g3);
	c3=connect_groups(bias,g2);
	c4=connect_groups(bias,g3);
	
	/* add connections to run network */ 
	bind_connection_to_net(run_net,c1);
	bind_connection_to_net(run_net,c2);
	bind_connection_to_net(run_net,c3);
	bind_connection_to_net(run_net,c4);
	
	/* randomize the weights in the connection objects. 
	     2nd argument is weight range. */ 
	randomize_connections(c1,WEIGHT_RANGE);
	randomize_connections(c2,WEIGHT_RANGE);
	randomize_connections(c3,WEIGHT_RANGE);
	randomize_connections(c4,WEIGHT_RANGE);
		
	/* done building the run_net object. all groups and connections are
	  accounted for. */
	
    /* define test sets: */
    

    /* define phase data: */
	  
	/* phase 1: */ 
	phases[0]=(Phase *)mh_calloc(sizeof(Phase),1);
	phases[0]->phase_name=(char *)mh_malloc(13);
	phases[0]->phase_name="defaultPhase";
	phases[0]->phase_order=0; //0=seq, 1=prob
	phases[0]->num_phase_items=1;
	phases[0]->max_iterations=1000;
	    
    /* define individual phase item data: */
    
	/* phase item 1: */ 
	Net *net1;
	net1=create_net(TIME);
	bind_group_to_net(net1,find_group_by_name("Input"));
	bind_group_to_net(net1,find_group_by_name("Hidden"));
	bind_group_to_net(net1,find_group_by_name("Output"));
	bind_group_to_net(net1,bias);
	bind_connection_to_net(net1,c1);
	bind_connection_to_net(net1,c2);
	bind_connection_to_net(net1,c3);
	bind_connection_to_net(net1,c4);
	phase_items[0]=(PhaseItem *)mh_calloc(sizeof(PhaseItem),1);
	phase_items[0]->net=net1;
	phase_items[0]->item_name=(char *)mh_malloc(12);
	phase_items[0]->item_name="train event";
	phase_items[0]->which_phase=0;
	phase_items[0]->test_only=0;
	phase_items[0]->num_tests=0;
	phase_items[0]->probability=0.0;
	phase_items[0]->total_group_readouts=3;
	phase_items[0]->group_readout_names=(char **)mh_calloc(3,sizeof(char*));
	phase_items[0]->group_readout_names[0]=(char *)mh_calloc(7,sizeof(char));
	phase_items[0]->group_readout_names[1]=(char *)mh_calloc(6,sizeof(char));
	phase_items[0]->group_readout_names[2]=(char *)mh_calloc(7,sizeof(char));
	phase_items[0]->group_readout_names[0]="Hidden";
	phase_items[0]->group_readout_names[1]="Input";
	phase_items[0]->group_readout_names[2]="Output";
	phase_items[0]->group_readout_times=(int *)mh_calloc(3,sizeof(int));
	phase_items[0]->group_readout_times[0]=0;
	phase_items[0]->group_readout_times[1]=1;
	phase_items[0]->group_readout_times[2]=2;
	int roTable0[3][TIME]={
	{1,1,1},
	{1,1,1},
	{1,1,1},
	};
	phase_items[0]->readout_table=(int **)mh_calloc(3,sizeof(int*));
	phase_items[0]->readout_table[0]=(int *)mh_calloc(TIME,sizeof(int));
	phase_items[0]->readout_table[1]=(int *)mh_calloc(TIME,sizeof(int));
	phase_items[0]->readout_table[2]=(int *)mh_calloc(TIME,sizeof(int));
	for(p=0;p<3;p++) {
		for(q=0;q<TIME;q++) {
			phase_items[0]->readout_table[p][q]=roTable0[p][q];
		}
	}
	phase_items[0]->total_activation_noise=0;
	phase_items[0]->total_input_noise=0;
	phase_items[0]->total_weight_noise=0;
	phase_items[0]->iter=0;
	phase_items[0]->wcount=0;
	phase_items[0]->ecount=0;
	phase_items[0]->tcount=0;
	phase_items[0]->ocount=0;
	phase_items[0]->error=0.0;
	
	phase_items[0]->train_examples=load_examples("/media/data/MikenetGUI/training_files/xor.ex",TIME);
	phase_items[0]->epsilon=1.0;
	phase_items[0]->momentum=0.0;
	phase_items[0]->tolerance=0.1;
	phase_items[0]->error_radius=0.0;
	phase_items[0]->max_iterations=10000;
	phase_items[0]->training_mode=0;
	phase_items[0]->dbd=0;
	phase_items[0]->training_algorithm=0;
	phase_items[0]->reset_activation=1;
	phase_items[0]->stop_criterion=0;
	phase_items[0]->seconds=1.0;
	phase_items[0]->tai=0;
	phase_items[0]->error_ramp=0;
	phase_items[0]->tao=1.0;
	phase_items[0]->tao_max_mult=-1.0;
	phase_items[0]->tao_min_mult=0.001;
	phase_items[0]->tao_epsilon=0.0;
	phase_items[0]->tao_decay=0.0;
	phase_items[0]->will_save_weights=0;
	phase_items[0]->save_weights_interval=500;
	phase_items[0]->will_save_error=1;
	phase_items[0]->save_error_interval=500;
	phase_items[0]->will_save_activations=0;
	phase_items[0]->save_activations_interval=500;
	phase_items[0]->test_interval=500;
	
	    
}